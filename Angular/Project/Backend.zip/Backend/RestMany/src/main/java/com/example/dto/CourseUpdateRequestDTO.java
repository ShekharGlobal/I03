package com.example.dto;


public class CourseUpdateRequestDTO {
    private Long courseId;
    @Override
	public String toString() {
		return "CourseUpdateRequestDTO [courseId=" + courseId + ", courseName=" + courseName + "]";
	}

	private String courseName;

    public Long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
