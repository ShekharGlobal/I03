import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyHelloWorldComponent } from './my-hello-world.component';

describe('MyHelloWorldComponent', () => {
  let component: MyHelloWorldComponent;
  let fixture: ComponentFixture<MyHelloWorldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyHelloWorldComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MyHelloWorldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
