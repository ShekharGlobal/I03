import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styles: []
})
export class ParentComponent {
  public products: Array<any> = [
    { p_id: 111, p_name: "TV", p_cost: 20000 },
    { p_id: 222, p_name: "Fridge", p_cost: 40000 },
    { p_id: 333, p_name: "Iphone", p_cost: 150000 },
    { p_id: 444, p_name: "Fan", p_cost: 1200 },
    { p_id: 555, p_name: "Dish Washer", p_cost: 50000 }
  ];

  public myFun(data: any) {
    alert(data);
  }
}
