import { Component, OnInit } from '@angular/core';
@Component({
 selector: 'tdf',
 templateUrl: './tdf.component.html',
 
})
export class TdfComponent  {
 

 register(data:any){
 console.log(data);
 
 }}
