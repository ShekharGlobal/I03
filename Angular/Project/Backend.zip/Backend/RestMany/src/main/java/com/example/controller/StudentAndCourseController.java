package com.example.controller;



import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.CourseUpdateRequestDTO;
import com.example.dto.StudentCourseDTO;
import com.example.dto.StudentUpdateRequestDTO;
import com.example.entity.Course;
import com.example.entity.Student;
import com.example.service.CourseService;
import com.example.service.StudentService;

@RestController
@CrossOrigin(origins = "http://localhost:4200") 
@RequestMapping("/api")
public class StudentAndCourseController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;


    
    @PostMapping("/studentAndCourses")
    public ResponseEntity<?> createStudentAndCourses(@RequestBody Map<String, Object> requestBody) {
        try {
            // Extract student data from JSON
            Map<String, Object> studentData = (Map<String, Object>) requestBody.get("student");
            String studentName = (String) studentData.get("name");

            // Create student
            Student student = new Student();
            student.setName(studentName);
            Student createdStudent = studentService.createStudent(student);

            // Extract courses data from JSON
            List<Map<String, Object>> coursesData = (List<Map<String, Object>>) requestBody.get("courses");
            List<Course> createdCourses = new ArrayList<>();

            // Create courses and associate them with the student
            for (Map<String, Object> courseData : coursesData) {
                String courseName = (String) courseData.get("name");
                Course course = new Course();
                course.setName(courseName);
                // Associate student with course
                course.getStudents().add(createdStudent);
                Course createdCourse = courseService.createCourse(course);
                createdCourses.add(createdCourse);
            }

            // Associate courses with the student
            createdStudent.getCourses().addAll(createdCourses);
            studentService.updateStudent(createdStudent); // Update student to save the associations

            // Return a JSON response with a success message
            return ResponseEntity.ok().body(Map.of("message", "Student and courses created successfully"));
        } catch (Exception e) {
            // Handle the exception and return an error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body(Map.of("error", "Failed to create student and courses: " + e.getMessage()));
        }
    }

    @GetMapping("/students/{id}/courses")
    public ResponseEntity<?> getStudentWithCourses(@PathVariable Long id) {
        try {
            Optional<Student> studentOptional = studentService.findStudentWithCoursesById(id);
            if (studentOptional.isPresent()) {
                Student student = studentOptional.get();
                // Create a DTO to hold both student and course information
                StudentCourseDTO studentCourseDTO = new StudentCourseDTO();
                studentCourseDTO.setId(student.getId());
                studentCourseDTO.setName(student.getName());
                List<Course> courses = new ArrayList<>(student.getCourses());
                studentCourseDTO.setCourses(courses);
                return ResponseEntity.ok().body(studentCourseDTO);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Failed to fetch student and courses: " + e.getMessage());
        }
    }

    
	
    
    @GetMapping("/view")
    public ResponseEntity<?> getStudentAndCourses() {
        try {
            List<Student> students = studentService.getAllStudents();
            List<StudentCourseDTO> studentCourseDTOs = new ArrayList<>();

            for (Student student : students) {
                StudentCourseDTO studentCourseDTO = new StudentCourseDTO();
                studentCourseDTO.setId(student.getId());
                studentCourseDTO.setName(student.getName());
                List<Course> courses = new ArrayList<>(student.getCourses());
                studentCourseDTO.setCourses(courses);
                studentCourseDTOs.add(studentCourseDTO);
            }

            return ResponseEntity.ok().body(studentCourseDTOs);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Failed to fetch students and courses: " + e.getMessage());
        }
    }

    @PutMapping("/students/{studentId}")
    public ResponseEntity<?> updateStudentAndCourse(
            @PathVariable Long studentId,
            @RequestBody StudentUpdateRequestDTO request) {
    	    System.out.println(request);
        try {
            // Retrieve student by ID
            Optional<Student> studentOptional = studentService.findStudentById(studentId);
            if (!studentOptional.isPresent()) {
                return ResponseEntity.notFound().build();
            }
            Student student = studentOptional.get();

            // Update student name
            student.setName(request.getStudentName());

            // Update associated courses (if needed)
            for (CourseUpdateRequestDTO courseUpdateRequest : request.getCourses()) {
                Optional<Course> courseOptional = courseService.findCourseById(courseUpdateRequest.getCourseId()); // Change getId() to getCourseId()
                if (courseOptional.isPresent()) {
                    Course course = courseOptional.get();
                    course.setName(courseUpdateRequest.getCourseName());
                    courseService.updateCourse(course);
                }
            }

            // Save updated student
            studentService.updateStudent(student);

            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Failed to update student and course: " + e.getMessage());
        }
    }

    @DeleteMapping("/students/{studentId}")
    public ResponseEntity<?> deleteStudentAndCourses(@PathVariable Long studentId) {
        try {
            studentService.deleteStudentAndCourses(studentId);
            return ResponseEntity.ok().body("Student and associated courses deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Failed to delete student and associated courses: " + e.getMessage());
        }
    }
}

    