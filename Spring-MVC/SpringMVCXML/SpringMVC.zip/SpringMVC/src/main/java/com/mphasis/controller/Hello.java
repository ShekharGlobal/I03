package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.service.Greeting;

@RestController
public class Hello {
	@Autowired
	public  Greeting greeting;
	
	//@RequestMapping("/Hello")
	@GetMapping("/hello")
	public String getName() {
		return "Welcome to REST";
	}
	
	@GetMapping("/greet")
	public String greeting() {
		return greeting.getGreeting();
	}

}
