import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyHelloWorldComponent } from './my-hello-world/my-hello-world.component';
import { MyComponent } from './my-component/my-component.component';
import { FormsModule } from '@angular/forms';
import { FirstComponent } from './my-comm/first.component';
import { SecondComponent } from './my-comm/second.component';
import { first } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent,
    MyHelloWorldComponent,
    MyComponent,FirstComponent, SecondComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [MyHelloWorldComponent,AppComponent,MyComponent,FirstComponent]
})
export class AppModule { }
