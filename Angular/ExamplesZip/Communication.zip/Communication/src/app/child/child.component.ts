import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styles: []
})
export class ChildComponent {
  @Input() p_id: any;
  @Input() p_name: any;
  @Input() p_cost: any;

  @Output() send: EventEmitter<any> = new EventEmitter();

  clickMe(): any {
    this.send.emit(this.p_id + "...." + this.p_name + "...." + this.p_cost);
  }
}
